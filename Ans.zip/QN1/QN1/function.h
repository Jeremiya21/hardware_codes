/*
 * function.h
 *
 * Created: 9/20/2023 2:27:01 PM
 *  Author: jeremiya
 */ 


#ifndef FUNCTION_H_
#define FUNCTION_H_
#include <stdint.h>
#include <stdbool.h>
void led_on(bool R,bool G,bool B,bool W);
#endif /* FUNCTION_H_ */