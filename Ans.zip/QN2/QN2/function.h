/*
 * function.h
 *
 * Created: 9/21/2023 11:24:17 AM
 *  Author: jeremiya
 */ 


#ifndef FUNCTION_H_
#define FUNCTION_H_

enum LED{R,G,B,W};
void function(enum LED led,uint32_t delay_1);

#endif /* FUNCTION_H_ */