#include <atmel_start.h>
void delayfn(int ,int ,int );
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	delayfn(100,50,200);
	return 0;
	
}
 