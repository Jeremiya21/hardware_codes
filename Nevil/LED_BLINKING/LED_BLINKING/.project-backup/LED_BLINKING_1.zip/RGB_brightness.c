/*
 * RGB_brightness.c
 *
 * Created: 30-09-2023 15:40:29
 *  Author: nevil
 */ 
void RGB_brightness(uint16_t a,uint16_t b, uint16_t c){
   TCA_SINGLE_CMP0_bm
}