/*
 * delay.h
 *
 * Created: 20-09-2023 15:52:38
 *  Author: nevil
 */ 


#ifndef DELAY_H_
#define DELAY_H_
enum led{R,G,B,W,RG,RB,RW,GB,GW,BW
};
void my_delay_ms(unsigned int ms);



#endif /* DELAY_H_ */