/*
 * func.h
 *
 * Created: 21-09-2023 11:29:15
 *  Author: nevil
 */ 


#ifndef FUNC_H_
#define FUNC_H_
void led_on(uint16_t delay_2);




#endif /* FUNC_H_ */