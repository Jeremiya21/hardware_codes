/*
 * led_ON.h
 *
 * Created: 20-09-2023 14:07:05
 *  Author: nevil
 */ 


#ifndef LED_ON_H_
#define LED_ON_H_
void led_ON(bool W,bool R,bool G,bool B);
#include <stdbool.h>



#endif /* LED_ON_H_ */