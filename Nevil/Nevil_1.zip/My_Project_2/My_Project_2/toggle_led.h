/*
 * toggle_led.h
 *
 * Created: 21-09-2023 11:21:10
 *  Author: nevil
 */ 


#ifndef TOGGLE_LED_H_
#define TOGGLE_LED_H_
void led_ON(bool W,bool R,bool G,bool B,uint32_t );




#endif /* TOGGLE_LED_H_ */