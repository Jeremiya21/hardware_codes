/*
 * delay.c
 *
 * Created: 20-09-2023 15:52:05
 *  Author: nevil
 */ 
void my_delay_ms(unsigned int ms) {
	while (ms > 0) {
		_delay_ms(1);
		ms--;
	}
}