/*
 * led_on.h
 *
 * Created: 21-09-2023 17:29:38
 *  Author: nevil
 */ 


#ifndef LED_ON_H_
#define LED_ON_H_
void led_ON(bool R,bool G,bool B);





#endif /* LED_ON_H_ */