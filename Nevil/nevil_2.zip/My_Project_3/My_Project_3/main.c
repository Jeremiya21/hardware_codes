#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		led_ON(1000,0,0);
		_delay_ms(500);
		led_ON(0,1000,0);
		_delay_ms(500);
		led_ON(0,0,1000);
		_delay_ms(500);
		led_ON(0,1000,1000);
		_delay_ms(500);
		led_ON(1000,0,1000);
		_delay_ms(500);
		led_ON(1000,1000,0);
		_delay_ms(500);
		led_ON(1000,1000,1000);
		_delay_ms(500);
		
		
	}
}
