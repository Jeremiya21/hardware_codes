/*
 * RGB_brightness.c
 *
 * Created: 30-09-2023 15:40:29
 *  Author: nevil
 */ 
void RGB_brightness(uint8_t a,uint8_t b, uint8_t c){
	    
		TCA_SINGLE_CMP0
		
		TCA0_SINGLE_CMP2
}